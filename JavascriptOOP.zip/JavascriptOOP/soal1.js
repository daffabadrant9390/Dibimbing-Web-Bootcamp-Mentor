/**
 * 3. Buat sebuah class Mahasiswa, yang memiliki 5 property
 *  - public property
 *    - nama
 *    - jurusan
 *    - Nomor Induk Mahasiswa
 *  - private property
 *    - usia
 *    - email
 *    - array nilai IPK X semester -> private method
 *
 * Buat 2 buah method
 *  - introduceSelf -> memperkenalkan diri mahasiswa
 *  - getGradeMahasiswa -> menentukan grade mahasiswa berdasarkan rata-rata IPK
 *
 * Gunakan setter dan getter untuk mengubah dan mengambil nilai dari
 *  - IPK mahasiswa
 *  - usia mahasiswa
 *  - email mahasiswa
 */

//* Lanjutkan code disini...
