/**
 * 2. Buatlah sebuah class User yang menerima 4 property
 * - nama
 * - username
 * - email
 * - password -> private property
 *
 * Buat dua buah method
 * - method login -> function untuk login user jika email dan passwordnya benar
 * - method checkPassword -> function untuk check apakah password yang diinput dan di property sama (PRIVATE METHOD)
 * - method checkEmail -> function untuk check apakah email yang diinput dan diproperty sama (PRIVATE METHOD);
 * - setter method untuk mengganti password (GETTER tidak perlu)
 */
