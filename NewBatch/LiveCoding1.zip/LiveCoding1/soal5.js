/**
 * RIGHT TRIANGLE
 * Membuat segitiga siku siku dengan 2 kondisi
 * - Kondisi 1 -> dimulai dari kiri
 * *
 * **
 * ***
 * ****
 * *****
 *
 * - Kondisi 2 -> dimulai dari kiri dan terbalik
 * *****
 * ****
 * ***
 * **
 * *
 *
 * - Kondisi 3 -> dimulai dari kiri kemudian dilanjutkan terbalik
 * *
 * **
 * ***
 * ****
 * *****
 * ****
 * ***
 * **
 * *
 *
 * Lakukan looping untuk menyelesaikan segitiga berikut!
 */
