/**
 * PERPANGKATAN
 * Lakukan looping pada angka 1-10, lalu lakukan pemangkatan dengan kondisi berikut
 * - Jika suatu angka merupakan bilangan genap DAN berada dibawag 5, maka lakukan pemangkatan dari angka 1-2
 * - Jika suatu angka merupakan bilangan ganjil DAN berada dibawah 5, maka lakukan pemangkatan dari angka 1-3
 * - Jika suatu angka berada diatas 5, maka lakukan pemangkatan dari angka 1 saja.
 */
