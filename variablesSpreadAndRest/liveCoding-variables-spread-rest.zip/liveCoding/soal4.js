/**
 * 4.Buatlah sebuah function yang menerima 2 parameter, yaitu
 * - object 1 dan object 2.
 *
 * Tugas:
 * - Gabungkanlah kedua object tersebut, dan jika object 2 sama dengan object 1, maka
 * replace lah fieldnya.
 */
