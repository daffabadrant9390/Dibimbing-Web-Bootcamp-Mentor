/**
 * 2. Filter, Merge and count the Total of array
 * Buatlah sebuah function yang menerima 2 parameter
 * - parameter 1 -> array of string dan number
 * - parameter 2 -> rest parameter (string, number, array)
 *
 * TUGAS:
 * Filter lah kedua array tersebut hingga hanya tersisa number. Lalu
 * Merge kedua array tersebut dan hitung total dari array tersebut!.
 *
 * CHALLENGE
 * - Buatlah sebuah function yang dapat digunakan berkali kali
 */

const getArraySudahDiFilter = (array) => {
  //* Lanjutkan code disini
};

const getTotalArrayNumber = (arrayData, ...restParameters) => {
  //* Filter arrayData dan restParameters
  //* Gabungkan arrayData dan restParameters yang telah di filter
  //* Hitung total dari kedua array tersebut setelah digabungkan!
};
