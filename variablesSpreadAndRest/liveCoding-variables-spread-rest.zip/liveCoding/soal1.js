/**
 * 1. Buatlah sebuah function yang menerima 2 parameter
 * - parameter 1 -> array of number
 * - parameter 2 -> rest parameter (number)
 *
 * Tugas
 * - Gabungkan 2 array tersebut menjadi 1 dengan spread operator
 * - Hitung lah total dari 2 array tersebut
 */

function menghitungTotalArray(arrayData, ...angkaAngkaTambahan) {
  //* Lanjutkan code disini untuk menggabungkan dan menghitung total
}
